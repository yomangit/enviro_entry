---
name: Bug report
about: Create a report to help improve LdapRecord
title: "[Bug]"
labels: bug
assignees: ''

---

<!--
  Please update the below information with your environment.
  Issues filed without the below information will be closed.
-->
**Environment:**
 - LDAP Server Type: [e.g. ActiveDirectory / OpenLDAP / FreeIPA]
 - PHP Version: [e.g. 7.3 / 7.4 / 8.0]

**Describe the bug:**
