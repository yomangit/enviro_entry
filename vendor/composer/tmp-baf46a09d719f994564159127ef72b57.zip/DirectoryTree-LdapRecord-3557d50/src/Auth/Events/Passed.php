<?php

namespace LdapRecord\Auth\Events;

class Passed extends Event
{
    //
}
