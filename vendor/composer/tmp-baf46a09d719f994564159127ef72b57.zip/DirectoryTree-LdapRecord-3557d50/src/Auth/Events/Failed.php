<?php

namespace LdapRecord\Auth\Events;

class Failed extends Event
{
    //
}
