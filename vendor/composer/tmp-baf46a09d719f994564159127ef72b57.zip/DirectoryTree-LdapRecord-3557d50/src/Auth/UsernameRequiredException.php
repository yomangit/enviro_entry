<?php

namespace LdapRecord\Auth;

use LdapRecord\LdapRecordException;

class UsernameRequiredException extends LdapRecordException
{
    //
}
