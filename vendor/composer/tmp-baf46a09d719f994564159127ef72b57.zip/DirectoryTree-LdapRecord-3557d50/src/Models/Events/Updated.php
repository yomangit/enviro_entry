<?php

namespace LdapRecord\Models\Events;

class Updated extends Event
{
    //
}
