<?php

namespace LdapRecord\Models\Events;

class Creating extends Event
{
    //
}
