<?php

namespace LdapRecord\Query\Filter;

use LdapRecord\LdapRecordException;

class ParserException extends LdapRecordException
{
}
