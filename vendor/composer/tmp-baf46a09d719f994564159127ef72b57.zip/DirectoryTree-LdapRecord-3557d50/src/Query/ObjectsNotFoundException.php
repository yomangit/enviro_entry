<?php

namespace LdapRecord\Query;

use LdapRecord\LdapRecordException;

class ObjectsNotFoundException extends LdapRecordException
{
}
